package com.cwrvmultiwick.multiwick.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey val id: String,
    val time: Long,
    val symbol: String,
    val direction: String,   // CALL | PUT
    val entryPrice: Double,
    val expiryAt: Long,
    val exitPrice: Double?,
    val status: String,      // pending | win | loss | draw
    val rule: String = "",   // "A" | "B" | "C" | "A,B" (multiple agreeing rules) - which detector fired
    val autoTraded: Boolean = false, // true if the demo auto-trader staked play money on this signal
    val netChange: Double? = null    // demo balance change once settled: +0.70 win, -1.00 loss, 0.0 draw
)
