package com.cwrvmultiwick.multiwick

import kotlin.math.abs
import kotlin.math.max

/**
 * CWRV Multi-Wick Regime Engine.
 *
 * Replaces the old fixed 3-rule wick detector with a REGIME-FIRST approach:
 * every closed candle is first classified into one of four market regimes
 * (see MarketRegimeDetector), and only then is a regime-specific playbook
 * consulted to decide whether a CALL / PUT / STAND_ASIDE signal fires.
 *
 *   REGIME_CHOPPY        -> always STAND_ASIDE (this regime is a hard veto).
 *   REGIME_TRENDING_*    -> pullback-to-EMA(20) with a rejection wick, in the
 *                           direction of the trend only (no counter-trend fires).
 *   REGIME_BREAKOUT      -> wait for a retest of the just-broken Donchian(20)
 *                           level with a rejection wick, then fire in the
 *                           direction of the original breakout (continuation).
 *   REGIME_RANGING       -> mean reversion off the outer Bollinger Band, gated
 *                           by an RSI extreme and a rejection wick at the band.
 *
 * Every rule described here is a mechanical implementation of a trading plan
 * discussed with the user - none of it has been independently back-tested.
 * Treat every signal as a hypothesis to validate on a demo account, not a
 * proven edge.
 */
object CWRVMultiWickEngine {

    data class Params(
        // Rejection-wick quality gate shared by all four playbooks: the wick
        // that "confirms" a setup must be at least this fraction of the
        // candle's total range, or it's treated as noise, not a rejection.
        val minRejectionWickRatio: Double = 0.30,
        // How close (in ATR multiples) price needs to come to the EMA(20) /
        // broken Donchian level / Bollinger Band to count as a genuine "touch".
        val touchToleranceAtrMultiplier: Double = 0.35,
        // Breakout retest: how many bars back (1-2 per the trading plan) we'll
        // look for the original breakout candle relative to the current bar.
        val breakoutRetestMaxBarsBack: Int = 2,
        val defaultExpirySeconds: Int = 60,
        val trendPullbackExpirySeconds: Int = 300,
        val breakoutRetestExpirySeconds: Int = 300
    )

    data class ChecklistItem(val pass: Boolean, val label: String, val sub: String)

    data class Result(
        val regime: MarketRegime,
        val context: MarketRegimeDetector.RegimeContext,
        val signalType: SignalType,
        val entryPrice: Double,
        val recommendedExpirySeconds: Int,
        val confidenceScore: Int,
        val reason: String,
        val checklist: List<ChecklistItem>,
        val volumeAvailable: Boolean,
        val direction: String?, // "CALL" | "PUT" | null, convenience mirror of signalType for UI/DB code
        val allPass: Boolean    // true when signalType != STAND_ASIDE
    )

    /** Evaluate the most recent closed candle in `candles` (last element = latest bar). */
    fun evaluate(candles: List<Candle>, params: Params = Params(), symbol: String = "", timeframe: String = "1m"): Result {
        val volumeAvailable = candles.isNotEmpty() && candles.any { it.volume > 0.0 }

        if (candles.size < 21) {
            return Result(
                regime = MarketRegime.REGIME_UNKNOWN,
                context = MarketRegimeDetector.analyze(candles),
                signalType = SignalType.STAND_ASIDE,
                entryPrice = candles.lastOrNull()?.close ?: 0.0,
                recommendedExpirySeconds = 0,
                confidenceScore = 0,
                reason = "অপর্যাপ্ত ক্যান্ডেল ডেটা (কমপক্ষে ২১টা লাগবে)",
                checklist = defaultChecklist(),
                volumeAvailable = volumeAvailable,
                direction = null,
                allPass = false
            )
        }

        val window = if (candles.size > 50) candles.takeLast(50) else candles
        val ctx = MarketRegimeDetector.analyze(window)
        val last = window.last()

        val playbook: PlaybookOutcome = when (ctx.regime) {
            MarketRegime.REGIME_CHOPPY -> PlaybookOutcome(
                SignalType.STAND_ASIDE, 0,
                "উচ্চ-নয়েজ চপি রেজিম শনাক্ত (ATR স্পাইক বা উইক-হেভি রেঞ্জ) — ট্রেড ব্লকড"
            )
            MarketRegime.REGIME_TRENDING_UP -> trendPullbackSignal(window, ctx, params, bullish = true)
            MarketRegime.REGIME_TRENDING_DOWN -> trendPullbackSignal(window, ctx, params, bullish = false)
            MarketRegime.REGIME_BREAKOUT -> breakoutRetestSignal(window, ctx, params)
            MarketRegime.REGIME_RANGING -> rangingMeanReversionSignal(window, ctx, params)
            MarketRegime.REGIME_UNKNOWN -> PlaybookOutcome(SignalType.STAND_ASIDE, 0, "কোনো রেজিম শর্ত মেলেনি এই মুহূর্তে")
        }

        val expiry = when (ctx.regime) {
            MarketRegime.REGIME_TRENDING_UP, MarketRegime.REGIME_TRENDING_DOWN -> params.trendPullbackExpirySeconds
            MarketRegime.REGIME_BREAKOUT -> params.breakoutRetestExpirySeconds
            MarketRegime.REGIME_RANGING -> params.defaultExpirySeconds
            else -> 0
        }.let { if (playbook.signalType == SignalType.STAND_ASIDE) 0 else it }

        return Result(
            regime = ctx.regime,
            context = ctx,
            signalType = playbook.signalType,
            entryPrice = last.close,
            recommendedExpirySeconds = expiry,
            confidenceScore = playbook.confidenceScore,
            reason = playbook.reason,
            checklist = buildChecklist(ctx),
            volumeAvailable = volumeAvailable,
            direction = when (playbook.signalType) {
                SignalType.CALL -> "CALL"
                SignalType.PUT -> "PUT"
                SignalType.STAND_ASIDE -> null
            },
            allPass = playbook.signalType != SignalType.STAND_ASIDE
        )
    }

    private data class PlaybookOutcome(val signalType: SignalType, val confidenceScore: Int, val reason: String)

    // ---- Regime 2: trending pullback-to-EMA(20) with rejection wick ----
    private fun trendPullbackSignal(candles: List<Candle>, ctx: MarketRegimeDetector.RegimeContext, params: Params, bullish: Boolean): PlaybookOutcome {
        val last = candles.last()
        val emaFast = ctx.emaFast ?: return PlaybookOutcome(SignalType.STAND_ASIDE, 0, "EMA(20) হিসাব করা যায়নি")
        val atr = ctx.atr ?: 0.0
        val tolerance = atr * params.touchToleranceAtrMultiplier

        return if (bullish) {
            val touchedFromBelow = last.low <= emaFast + tolerance && last.close > emaFast
            val rejectionWick = last.lowerWick / max(last.totalRange, 1e-9) >= params.minRejectionWickRatio
            if (touchedFromBelow && rejectionWick) {
                val strength = ((ctx.adx ?: 25.0) - 25.0).coerceIn(0.0, 25.0)
                PlaybookOutcome(SignalType.CALL, (65 + strength).toInt().coerceAtMost(95),
                    "আপট্রেন্ডে EMA(20) পুলব্যাক + লোয়ার রিজেকশন উইক — CALL কন্টিনিউয়েশন")
            } else {
                PlaybookOutcome(SignalType.STAND_ASIDE, 0, "আপট্রেন্ড চলছে কিন্তু EMA(20) পুলব্যাক/রিজেকশন উইক শর্ত মেলেনি")
            }
        } else {
            val touchedFromAbove = last.high >= emaFast - tolerance && last.close < emaFast
            val rejectionWick = last.upperWick / max(last.totalRange, 1e-9) >= params.minRejectionWickRatio
            if (touchedFromAbove && rejectionWick) {
                val strength = ((ctx.adx ?: 25.0) - 25.0).coerceIn(0.0, 25.0)
                PlaybookOutcome(SignalType.PUT, (65 + strength).toInt().coerceAtMost(95),
                    "ডাউনট্রেন্ডে EMA(20) পুলব্যাক + আপার রিজেকশন উইক — PUT কন্টিনিউয়েশন")
            } else {
                PlaybookOutcome(SignalType.STAND_ASIDE, 0, "ডাউনট্রেন্ড চলছে কিন্তু EMA(20) পুলব্যাক/রিজেকশন উইক শর্ত মেলেনি")
            }
        }
    }

    // ---- Regime 3: breakout, then retest of the broken level within 1-2 bars ----
    private fun breakoutRetestSignal(candles: List<Candle>, ctx: MarketRegimeDetector.RegimeContext, params: Params): PlaybookOutcome {
        val n = candles.size
        val last = candles.last()
        val atr = ctx.atr ?: 0.0
        val tolerance = atr * params.touchToleranceAtrMultiplier

        // The current bar IS the breakout bar itself -> too early, wait for the retest.
        val priorHigh = MarketRegimeDetector.donchianHigh(candles, n - 1, MarketRegimeDetector.Thresholds.DONCHIAN_PERIOD)
        val priorLow = MarketRegimeDetector.donchianLow(candles, n - 1, MarketRegimeDetector.Thresholds.DONCHIAN_PERIOD)
        val thisBarBrokeOut = (priorHigh != null && last.close > priorHigh) || (priorLow != null && last.close < priorLow)
        if (thisBarBrokeOut) {
            return PlaybookOutcome(SignalType.STAND_ASIDE, 0, "ব্রেকআউট ক্যান্ডেল সবে তৈরি হলো — রিটেস্টের জন্য অপেক্ষা")
        }

        // Look 1-2 bars back for the breakout candle + the level it broke.
        for (barsBack in 1..params.breakoutRetestMaxBarsBack) {
            val breakoutIdx = n - 1 - barsBack
            if (breakoutIdx < MarketRegimeDetector.Thresholds.DONCHIAN_PERIOD) continue
            val breakoutCandle = candles[breakoutIdx]
            val bodyRatio = MarketRegimeDetector.bodyToRangeRatio(breakoutCandle)
            if (bodyRatio <= MarketRegimeDetector.Thresholds.BREAKOUT_BODY_RATIO) continue

            val levelHigh = MarketRegimeDetector.donchianHigh(candles, breakoutIdx, MarketRegimeDetector.Thresholds.DONCHIAN_PERIOD)
            val levelLow = MarketRegimeDetector.donchianLow(candles, breakoutIdx, MarketRegimeDetector.Thresholds.DONCHIAN_PERIOD)

            val brokeUp = levelHigh != null && breakoutCandle.close > levelHigh
            val brokeDown = levelLow != null && breakoutCandle.close < levelLow

            if (brokeUp && levelHigh != null) {
                val retested = last.low <= levelHigh + tolerance && last.close > levelHigh
                val rejectionWick = last.lowerWick / max(last.totalRange, 1e-9) >= params.minRejectionWickRatio
                if (retested && rejectionWick) {
                    return PlaybookOutcome(SignalType.CALL, 75,
                        "ব্রেকআউট লেভেল (${formatPrice(levelHigh)}) রিটেস্ট + লোয়ার রিজেকশন উইক — CALL কন্টিনিউয়েশন")
                }
            }
            if (brokeDown && levelLow != null) {
                val retested = last.high >= levelLow - tolerance && last.close < levelLow
                val rejectionWick = last.upperWick / max(last.totalRange, 1e-9) >= params.minRejectionWickRatio
                if (retested && rejectionWick) {
                    return PlaybookOutcome(SignalType.PUT, 75,
                        "ব্রেকআউট লেভেল (${formatPrice(levelLow)}) রিটেস্ট + আপার রিজেকশন উইক — PUT কন্টিনিউয়েশন")
                }
            }
        }
        return PlaybookOutcome(SignalType.STAND_ASIDE, 0, "ব্রেকআউট হয়েছে কিন্তু এখনো রিজেকশন-উইক রিটেস্ট কনফার্ম হয়নি")
    }

    // ---- Regime 4: ranging mean reversion off the outer Bollinger Band + RSI extreme ----
    private fun rangingMeanReversionSignal(candles: List<Candle>, ctx: MarketRegimeDetector.RegimeContext, params: Params): PlaybookOutcome {
        val last = candles.last()
        val bb = ctx.bollinger ?: return PlaybookOutcome(SignalType.STAND_ASIDE, 0, "Bollinger Bands হিসাব করা যায়নি")
        val rsiVal = ctx.rsi ?: return PlaybookOutcome(SignalType.STAND_ASIDE, 0, "RSI হিসাব করা যায়নি")

        val touchedUpper = last.high >= bb.upper
        val overbought = rsiVal >= MarketRegimeDetector.Thresholds.RSI_OVERBOUGHT
        val upperRejection = last.upperWick / max(last.totalRange, 1e-9) >= params.minRejectionWickRatio

        val touchedLower = last.low <= bb.lower
        val oversold = rsiVal <= MarketRegimeDetector.Thresholds.RSI_OVERSOLD
        val lowerRejection = last.lowerWick / max(last.totalRange, 1e-9) >= params.minRejectionWickRatio

        return when {
            touchedUpper && overbought && upperRejection -> {
                val strength = (rsiVal - MarketRegimeDetector.Thresholds.RSI_OVERBOUGHT).coerceIn(0.0, 20.0)
                PlaybookOutcome(SignalType.PUT, (60 + strength).toInt().coerceAtMost(90),
                    "রেঞ্জিং মার্কেটে Upper BB টাচ + RSI ওভারবট (${rsiVal.toInt()}) + আপার রিজেকশন উইক — PUT (Lower)")
            }
            touchedLower && oversold && lowerRejection -> {
                val strength = (MarketRegimeDetector.Thresholds.RSI_OVERSOLD - rsiVal).coerceIn(0.0, 20.0)
                PlaybookOutcome(SignalType.CALL, (60 + strength).toInt().coerceAtMost(90),
                    "রেঞ্জিং মার্কেটে Lower BB টাচ + RSI ওভারসোল্ড (${rsiVal.toInt()}) + লোয়ার রিজেকশন উইক — CALL (Higher)")
            }
            else -> PlaybookOutcome(SignalType.STAND_ASIDE, 0, "রেঞ্জিং মার্কেট কিন্তু BB+RSI+উইক শর্ত এখনো মেলেনি")
        }
    }

    private fun defaultChecklist(): List<ChecklistItem> = listOf(
        ChecklistItem(false, "রেজিম ১: চপি / হাই-নয়েজ ফিল্টার", "অপেক্ষা করছে…"),
        ChecklistItem(false, "রেজিম ২: ট্রেন্ডিং (EMA পুলব্যাক)", "অপেক্ষা করছে…"),
        ChecklistItem(false, "রেজিম ৩: ব্রেকআউট + রিটেস্ট", "অপেক্ষা করছে…"),
        ChecklistItem(false, "রেজিম ৪: রেঞ্জিং (BB + RSI মিন-রিভার্সন)", "অপেক্ষা করছে…")
    )

    private fun buildChecklist(ctx: MarketRegimeDetector.RegimeContext): List<ChecklistItem> {
        val atrLabel = if (ctx.atr != null && ctx.atrSmaBaseline != null)
            "ATR ${String.format("%.5f", ctx.atr)} vs baseline ${String.format("%.5f", ctx.atrSmaBaseline)}"
        else "ATR ডেটা অপর্যাপ্ত"
        val adxLabel = ctx.adx?.let { "ADX(14) = ${String.format("%.1f", it)}" } ?: "ADX অপর্যাপ্ত ডেটা"
        val bwLabel = ctx.bandwidthExpansionPct?.let { "BB bandwidth Δ = ${String.format("%.1f", it * 100)}%" } ?: "Bandwidth অপর্যাপ্ত ডেটা"
        val rsiLabel = ctx.rsi?.let { "RSI(14) = ${String.format("%.1f", it)}" } ?: "RSI অপর্যাপ্ত ডেটা"

        return listOf(
            ChecklistItem(
                pass = ctx.regime == MarketRegime.REGIME_CHOPPY,
                label = "রেজিম ১: চপি / হাই-নয়েজ ফিল্টার",
                sub = "$atrLabel • wick ratio ${ctx.choppyWickRatio?.let { String.format("%.2f", it) } ?: "—"}"
            ),
            ChecklistItem(
                pass = ctx.regime == MarketRegime.REGIME_TRENDING_UP || ctx.regime == MarketRegime.REGIME_TRENDING_DOWN,
                label = "রেজিম ২: ট্রেন্ডিং (EMA পুলব্যাক)",
                sub = "$adxLabel • EMA20 ${ctx.emaFast?.let { formatPrice(it) } ?: "—"} / EMA50 ${ctx.emaSlow?.let { formatPrice(it) } ?: "—"}"
            ),
            ChecklistItem(
                pass = ctx.regime == MarketRegime.REGIME_BREAKOUT,
                label = "রেজিম ৩: ব্রেকআউট + রিটেস্ট",
                sub = bwLabel
            ),
            ChecklistItem(
                pass = ctx.regime == MarketRegime.REGIME_RANGING,
                label = "রেজিম ৪: রেঞ্জিং (BB + RSI মিন-রিভার্সন)",
                sub = "$adxLabel • $rsiLabel"
            )
        )
    }
}
