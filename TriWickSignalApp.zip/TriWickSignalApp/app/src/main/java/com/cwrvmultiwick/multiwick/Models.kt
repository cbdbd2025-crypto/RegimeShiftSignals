package com.cwrvmultiwick.multiwick

import java.util.Locale

/**
 * A single OHLCV candle. `openTime` is epoch millis for the candle's open.
 *
 * Tick volume / trade volume depending on source. 0.0 when the source doesn't
 * report volume at all (some forex feeds) — engines treat 0-volume series as
 * "volume unavailable" and skip volume-dependent conditions accordingly.
 */
data class Candle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0
) {
    /** abs(close - open). Always >= 0. */
    val body: Double get() = kotlin.math.abs(close - open)

    /** high - low. Always >= 0 (guarded against inverted/bad ticks upstream). */
    val totalRange: Double get() = high - low

    /** Wick above the real body. */
    val upperWick: Double get() = high - maxOf(open, close)

    /** Wick below the real body. */
    val lowerWick: Double get() = minOf(open, close) - low

    val isBullish: Boolean get() = close > open
    val isBearish: Boolean get() = close < open
    val isDoji: Boolean get() = close == open
}

/** The four mutually-exclusive market regimes this engine classifies into. */
enum class MarketRegime {
    REGIME_CHOPPY,
    REGIME_TRENDING_UP,
    REGIME_TRENDING_DOWN,
    REGIME_BREAKOUT,
    REGIME_RANGING,
    /** Not enough candles yet to classify anything. */
    REGIME_UNKNOWN
}

enum class SignalType {
    CALL,
    PUT,
    STAND_ASIDE
}

/**
 * Output of one full evaluation cycle: regime classification + (optionally) a
 * binary-options signal derived from that regime's playbook.
 */
data class SignalResult(
    val symbol: String,
    val timeframe: String,
    val regime: MarketRegime,
    val signalType: SignalType,
    val entryPrice: Double,
    val recommendedExpirySeconds: Int,
    val confidenceScore: Int, // 0..100
    val reason: String,
    val timestamp: Long
)

fun formatPrice(p: Double): String =
    if (p < 10) String.format(Locale.US, "%.4f", p) else String.format(Locale.US, "%.2f", p)
