package com.cwrvmultiwick.multiwick.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("confirm_signal_prefs", Context.MODE_PRIVATE)

    var dataSource: String
        get() = sp.getString("dataSource", "crypto") ?: "crypto"
        set(v) = sp.edit().putString("dataSource", v).apply()

    var symbol: String
        get() = sp.getString("symbol", "BTCUSDT") ?: "BTCUSDT"
        set(v) = sp.edit().putString("symbol", v).apply()

    // Stored locally on-device only — never hardcode this in source code.
    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v).apply()

    var pollSeconds: Int
        get() = sp.getInt("pollSeconds", 1)
        set(v) = sp.edit().putInt("pollSeconds", v).apply()

    var expiryMinutes: Int
        get() = sp.getInt("expiryMinutes", 1)
        set(v) = sp.edit().putInt("expiryMinutes", v).apply()

    // No longer enforced as a cap (daily signal limit removed per user request) — kept
    // only so old stored values don't crash anything if referenced elsewhere.
    var maxSignalsPerDay: Int
        get() = sp.getInt("maxSignalsPerDay", 2)
        set(v) = sp.edit().putInt("maxSignalsPerDay", v).apply()

    var muted: Boolean
        get() = sp.getBoolean("muted", false)
        set(v) = sp.edit().putBoolean("muted", v).apply()

    var serviceRunning: Boolean
        get() = sp.getBoolean("serviceRunning", false)
        set(v) = sp.edit().putBoolean("serviceRunning", v).apply()

    var signalsFiredToday: Int
        get() = sp.getInt("signalsFiredToday", 0)
        set(v) = sp.edit().putInt("signalsFiredToday", v).apply()

    var lastSignalDay: String
        get() = sp.getString("lastSignalDay", "") ?: ""
        set(v) = sp.edit().putString("lastSignalDay", v).apply()

    // ---- Demo binary-options auto-trading (paper money only, never real funds) ----
    var demoBalance: Double
        get() = sp.getFloat("demoBalance", 0f).toDouble()
        set(v) = sp.edit().putFloat("demoBalance", v.toFloat()).apply()

    var autoTradeEnabled: Boolean
        get() = sp.getBoolean("autoTradeEnabled", false)
        set(v) = sp.edit().putBoolean("autoTradeEnabled", v).apply()

    // ---- Loss-reduction filters (trend filter, confluence, cooldown) ----
    var trendFilterEnabled: Boolean
        get() = sp.getBoolean("trendFilterEnabled", true)
        set(v) = sp.edit().putBoolean("trendFilterEnabled", v).apply()

    var confluenceEnabled: Boolean
        get() = sp.getBoolean("confluenceEnabled", true)
        set(v) = sp.edit().putBoolean("confluenceEnabled", v).apply()

    // Minimum minutes between two fired signals on the SAME symbol (any rule),
    // to stop rapid-fire re-entries right after a loss/win. 0 = no cooldown.
    var cooldownMinutes: Int
        get() = sp.getInt("cooldownMinutes", 3)
        set(v) = sp.edit().putInt("cooldownMinutes", v).apply()

    // ---- Per-symbol last-fired-signal time (cooldown enforcement) ----
    private fun parseSymbolTimeMap(key: String): MutableMap<String, Long> {
        val raw = sp.getString(key, "") ?: ""
        if (raw.isBlank()) return mutableMapOf()
        return raw.split(";").mapNotNull { entry ->
            val idx = entry.lastIndexOf('=')
            if (idx <= 0) return@mapNotNull null
            val k = entry.substring(0, idx)
            val t = entry.substring(idx + 1).toLongOrNull() ?: return@mapNotNull null
            k to t
        }.toMap().toMutableMap()
    }

    fun getLastGlobalSignalTime(symbol: String): Long = parseSymbolTimeMap("lastGlobalSignalTimeMap")[symbol] ?: 0L

    fun setLastGlobalSignalTime(symbol: String, time: Long) {
        val map = parseSymbolTimeMap("lastGlobalSignalTimeMap")
        map[symbol] = time
        val serialized = map.entries.joinToString(";") { "${it.key}=${it.value}" }
        sp.edit().putString("lastGlobalSignalTimeMap", serialized).apply()
    }

    // ---- Multi-symbol watchlist ----
    // Background service now loops over every entry here each poll cycle instead of
    // only the one symbol shown in the live chart. Keys are "source::symbol", e.g.
    // "crypto::BTCUSDT" or "oanda::EUR/USD". Defaults to whatever the currently
    // selected source/symbol is, so upgrading from a single-symbol setup doesn't
    // silently stop monitoring what the user already had selected.
    var watchlist: Set<String>
        get() {
            val stored = sp.getStringSet("watchlist", null)
            return stored ?: setOf("$dataSource::$symbol")
        }
        set(v) = sp.edit().putStringSet("watchlist", v).apply()

    fun watchKey(source: String, symbol: String): String = "$source::$symbol"

    fun isWatched(source: String, symbol: String): Boolean =
        watchlist.contains(watchKey(source, symbol))

    fun setWatched(source: String, symbol: String, watched: Boolean) {
        val key = watchKey(source, symbol)
        watchlist = if (watched) watchlist + key else watchlist - key
    }

    // ---- Per-symbol last-fired bar time (prevents re-firing the same signal candle) ----
    // Stored as "key1=time1;key2=time2;..." since SharedPreferences has no native map type.
    private fun parseBarTimeMap(): MutableMap<String, Long> {
        val raw = sp.getString("lastSignalBarTimeMap", "") ?: ""
        if (raw.isBlank()) return mutableMapOf()
        return raw.split(";").mapNotNull { entry ->
            val idx = entry.lastIndexOf('=')
            if (idx <= 0) return@mapNotNull null
            val k = entry.substring(0, idx)
            val t = entry.substring(idx + 1).toLongOrNull() ?: return@mapNotNull null
            k to t
        }.toMap().toMutableMap()
    }

    fun getLastSignalBarTime(key: String): Long = parseBarTimeMap()[key] ?: 0L

    fun setLastSignalBarTime(key: String, time: Long) {
        val map = parseBarTimeMap()
        map[key] = time
        val serialized = map.entries.joinToString(";") { "${it.key}=${it.value}" }
        sp.edit().putString("lastSignalBarTimeMap", serialized).apply()
    }
}
