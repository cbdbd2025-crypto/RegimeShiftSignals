package com.cwrvmultiwick.multiwick

import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import com.cwrvmultiwick.multiwick.data.AppDatabase
import com.cwrvmultiwick.multiwick.data.Prefs
import com.cwrvmultiwick.multiwick.data.SignalEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class SignalForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private lateinit var prefs: Prefs
    private lateinit var db: AppDatabase

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        db = AppDatabase.getInstance(this)
        NotificationHelper.ensureChannels(this)
        startForeground(NotificationHelper.SERVICE_NOTIF_ID, NotificationHelper.buildServiceNotification(this, "মনিটরিং শুরু হচ্ছে…"))
        prefs.serviceRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (job == null || job?.isActive != true) {
            job = serviceScope.launch { loop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        prefs.serviceRunning = false
        job?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private suspend fun CoroutineScope.loop() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        while (isActive) {
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ConfirmSignal:poll")
            try {
                wl.acquire(20_000)
                runCycle()
            } catch (e: Exception) {
                updateNotif("সংযোগ ত্রুটি: ${e.message ?: "unknown"}")
            } finally {
                if (wl.isHeld) wl.release()
            }
            val pollSec = prefs.pollSeconds.coerceIn(1, 60)
            delay(pollSec * 1000L)
        }
    }

    private suspend fun runCycle() {
        checkNewDay()

        val watchlist = prefs.watchlist
        if (watchlist.isEmpty()) { updateNotif("ওয়াচলিস্ট খালি — অ্যাপে অন্তত ১টা সিম্বল সিলেক্ট করুন"); return }

        var lastStatusText = ""
        var errorCount = 0

        for (key in watchlist) {
            val parts = key.split("::", limit = 2)
            if (parts.size != 2) continue
            val source = parts[0]
            val symbol = parts[1]

            try {
                val m1: List<Candle> = when (source) {
                    "crypto" -> NetworkClients.fetchBinanceKlines(symbol, "1m", 150)
                    "oanda" -> {
                        val key2 = prefs.apiKey
                        if (key2.isBlank()) { errorCount++; continue }
                        NetworkClients.fetchOandaCandles(symbol.replace("/", "_"), "M1", 150, key2)
                    }
                    "yahoo" -> {
                        val ticker = symbol.replace("/", "") + "=X"
                        NetworkClients.fetchYahooCandles(ticker, "1m", "1d")
                    }
                    else -> {
                        val key2 = prefs.apiKey
                        if (key2.isBlank()) { errorCount++; continue }
                        NetworkClients.fetchTwelveDataKlines(symbol, "1m", 150, key2)
                    }
                }

                if (m1.size < 30) continue

                // Grade any pending signals for this symbol using the latest live price
                val liveClose = m1.last().close
                gradePending(symbol, liveClose)

                val closedM1 = m1.dropLast(1) // exclude currently-forming candle
                if (closedM1.size < 29) continue

                val last = closedM1.last()
                val params = CWRVMultiWickEngine.Params()
                val result = CWRVMultiWickEngine.evaluate(closedM1, params, symbol, "1m")

                lastStatusText = "$symbol ${formatPrice(liveClose)}"

                // The regime engine already vetoes CHOPPY internally (STAND_ASIDE), and
                // each regime's playbook only fires in its own trend/mean-reversion
                // direction, so there's no separate confluence gate needed here anymore.
                // Two gates remain before an actual trade is logged/notified:
                //  - de-dup: don't re-fire twice for the same closed bar on this symbol
                //  - cooldown: don't re-fire on the same symbol within cooldownMinutes
                val dir = result.direction
                val cooldownMs = prefs.cooldownMinutes.coerceAtLeast(0) * 60_000L
                if (dir != null) {
                    val signalKey = "$key::regime"
                    val now = System.currentTimeMillis()
                    val alreadyFiredThisBar = last.openTime == prefs.getLastSignalBarTime(signalKey)
                    val withinCooldown = cooldownMs > 0 && now - prefs.getLastGlobalSignalTime(symbol) < cooldownMs
                    if (!alreadyFiredThisBar && !withinCooldown) {
                        prefs.setLastSignalBarTime(signalKey, last.openTime)
                        prefs.setLastGlobalSignalTime(symbol, now)
                        fireSignal(dir, symbol, liveClose, last.openTime, result.regime.name, result.reason)
                    }
                }
            } catch (e: Exception) {
                errorCount++
                // Keep going — one symbol's fetch failure (rate limit, network blip)
                // shouldn't stop the rest of the watchlist from being checked.
            }
        }

        val watchedCount = watchlist.size
        updateNotif(
            if (errorCount > 0) "$watchedCount সিম্বল মনিটর হচ্ছে • $lastStatusText • $errorCount টায় ত্রুটি"
            else "$watchedCount সিম্বল মনিটর হচ্ছে • $lastStatusText"
        )
    }

    private suspend fun gradePending(symbol: String, latestPrice: Double) {
        val now = System.currentTimeMillis()
        val pending = db.signalDao().getPending().filter { it.symbol == symbol && now >= it.expiryAt }
        for (r in pending) {
            val status = when {
                latestPrice == r.entryPrice -> "draw"
                r.direction == "CALL" -> if (latestPrice > r.entryPrice) "win" else "loss"
                else -> if (latestPrice < r.entryPrice) "win" else "loss"
            }

            // Settle the demo stake, if this signal was auto-traded. The stake ($1 play
            // money) was already deducted from the demo balance when the trade opened, so:
            //  - win  -> credit the full payout (stake back + profit)
            //  - loss -> nothing to credit, the stake is already gone
            //  - draw -> refund just the stake, no profit/loss
            var netChange: Double? = null
            if (r.autoTraded) {
                netChange = when (status) {
                    "win" -> {
                        prefs.demoBalance += DEMO_PAYOUT
                        DEMO_PAYOUT - DEMO_STAKE
                    }
                    "draw" -> {
                        prefs.demoBalance += DEMO_STAKE
                        0.0
                    }
                    else -> -DEMO_STAKE // loss
                }
            }

            db.signalDao().update(r.copy(exitPrice = latestPrice, status = status, netChange = netChange))
        }
    }

    private suspend fun fireSignal(direction: String, symbol: String, entryPrice: Double, barTime: Long, regime: String, reason: String) {
        prefs.signalsFiredToday += 1

        // Demo auto-trading: if enabled and there's enough play money, stake $1 on this
        // signal the moment it fires. Nothing here ever touches real money — demoBalance
        // is a local SharedPreferences counter only.
        val autoTraded = prefs.autoTradeEnabled && prefs.demoBalance >= DEMO_STAKE
        if (autoTraded) {
            prefs.demoBalance -= DEMO_STAKE
        }

        val record = SignalEntity(
            id = "sig_${System.currentTimeMillis()}_${Random.nextInt(10000)}",
            time = System.currentTimeMillis(),
            symbol = symbol,
            direction = direction,
            entryPrice = entryPrice,
            expiryAt = System.currentTimeMillis() + prefs.expiryMinutes * 60_000L,
            exitPrice = null,
            status = "pending",
            rule = regime,
            autoTraded = autoTraded
        )
        db.signalDao().insert(record)

        val regimeLabel = regimeLabelBn(regime)

        if (!prefs.muted) {
            val tradeSuffix = if (autoTraded) " • 🤖 ডেমো $১ ট্রেড ওপেন" else ""
            NotificationHelper.sendSignalNotification(
                this,
                "$direction সিগন্যাল — $symbol ($regimeLabel)",
                "এন্ট্রি ${formatPrice(entryPrice)} • ${prefs.expiryMinutes}মি এক্সপায়ারি$tradeSuffix",
                notifId = System.currentTimeMillis().toInt()
            )
        }
    }

    private fun regimeLabelBn(regime: String): String = when (regime) {
        "REGIME_TRENDING_UP" -> "ট্রেন্ডিং আপ · EMA পুলব্যাক"
        "REGIME_TRENDING_DOWN" -> "ট্রেন্ডিং ডাউন · EMA পুলব্যাক"
        "REGIME_BREAKOUT" -> "ব্রেকআউট · রিটেস্ট"
        "REGIME_RANGING" -> "রেঞ্জিং · BB+RSI মিন-রিভার্সন"
        "REGIME_CHOPPY" -> "চপি"
        else -> regime
    }

    companion object {
        // Fixed demo stake/payout per trade (play money only): $1 in, $1.70 back on a win.
        const val DEMO_STAKE = 1.0
        const val DEMO_PAYOUT = 1.70
    }

    private fun checkNewDay() {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = sdf.format(Date())
        if (prefs.lastSignalDay != today) {
            prefs.lastSignalDay = today
            prefs.signalsFiredToday = 0
        }
    }

    private fun formatPrice(p: Double): String =
        if (p < 10) String.format(Locale.US, "%.4f", p) else String.format(Locale.US, "%.2f", p)

    private fun updateNotif(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NotificationHelper.SERVICE_NOTIF_ID, NotificationHelper.buildServiceNotification(this, text))
    }
}
