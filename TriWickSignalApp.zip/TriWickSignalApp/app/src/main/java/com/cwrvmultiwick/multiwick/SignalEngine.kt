package com.cwrvmultiwick.multiwick

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Pure computation + orchestration layer shared by the live UI (MainActivity) and
 * the background SignalForegroundService. Network I/O happens on Dispatchers.IO
 * (inside NetworkClients); the actual regime classification + signal math runs on
 * Dispatchers.Default so bar evaluation never blocks the UI thread, even at
 * high polling frequency.
 *
 * Regime classification + per-regime playbooks live in MarketRegimeDetector.kt
 * and CWRVMultiWickEngine.kt. This file just wires "fetch candles" -> "evaluate"
 * -> "shape the result for whichever caller needs it".
 */
object SignalEngine {

    data class CycleResult(
        val chartCandles: List<Candle>,
        val chartBbUpper: List<Double?>,
        val chartBbLower: List<Double?>,
        val liveClose: Double,
        val changePct: Double,
        val bias: String,
        val showCall: Boolean,
        val checklist: List<CWRVMultiWickEngine.ChecklistItem>,
        val allPass: Boolean,
        val volumeAvailable: Boolean,
        val regime: MarketRegime,
        val signal: SignalResult,
        val lastOpenTime: Long,
        val lastClose: Double
    )

    private fun toYahooTicker(symbol: String): String = symbol.replace("/", "") + "=X"

    suspend fun runCycle(
        source: String,
        symbol: String,
        apiKey: String,
        params: CWRVMultiWickEngine.Params = CWRVMultiWickEngine.Params()
    ): CycleResult {
        val m1: List<Candle>
        when (source) {
            "crypto" -> {
                m1 = NetworkClients.fetchBinanceKlines(symbol, "1m", 100)
            }
            "oanda" -> {
                if (apiKey.isBlank()) throw Exception("OANDA personal access token নেই")
                val instrument = symbol.replace("/", "_")
                m1 = NetworkClients.fetchOandaCandles(instrument, "M1", 100, apiKey)
            }
            "yahoo" -> {
                m1 = NetworkClients.fetchYahooCandles(toYahooTicker(symbol), "1m", "1d")
            }
            else -> {
                if (apiKey.isBlank()) throw Exception("Twelve Data API key নেই")
                m1 = NetworkClients.fetchTwelveDataKlines(symbol, "1m", 100, apiKey)
            }
        }
        if (m1.size < 25) throw Exception("অপর্যাপ্ত ডেটা")

        val closedM1 = m1.dropLast(1) // exclude currently-forming candle
        if (closedM1.size < 24) throw Exception("অপেক্ষা করছে…")

        return evaluateForUi(closedM1, m1.last().close, symbol, source, params)
    }

    /** Non-blocking evaluation entry point: does all math off the main thread. */
    suspend fun evaluateForUi(
        closedCandles: List<Candle>,
        liveClose: Double,
        symbol: String,
        timeframe: String,
        params: CWRVMultiWickEngine.Params = CWRVMultiWickEngine.Params()
    ): CycleResult = withContext(Dispatchers.Default) {
        val last = closedCandles.last()
        val result = CWRVMultiWickEngine.evaluate(closedCandles, params, symbol, timeframe)

        val regimeLabelBn = when (result.regime) {
            MarketRegime.REGIME_CHOPPY -> "চপি"
            MarketRegime.REGIME_TRENDING_UP -> "আপট্রেন্ড"
            MarketRegime.REGIME_TRENDING_DOWN -> "ডাউনট্রেন্ড"
            MarketRegime.REGIME_BREAKOUT -> "ব্রেকআউট"
            MarketRegime.REGIME_RANGING -> "রেঞ্জিং"
            MarketRegime.REGIME_UNKNOWN -> "অনির্ধারিত"
        }
        val bias = when (result.signalType) {
            SignalType.CALL -> "CALL ($regimeLabelBn, আস্থা ${result.confidenceScore}%)"
            SignalType.PUT -> "PUT ($regimeLabelBn, আস্থা ${result.confidenceScore}%)"
            SignalType.STAND_ASIDE -> "STAND_ASIDE ($regimeLabelBn)"
        }
        val showCall = result.signalType != SignalType.PUT

        val prevClose = if (closedCandles.size >= 2) closedCandles[closedCandles.size - 2].close else liveClose
        val changePct = if (prevClose != 0.0) (liveClose - prevClose) / prevClose * 100 else 0.0

        val chartN = 40
        val chartSlice = closedCandles.takeLast(chartN)
        val chartCloses = chartSlice.map { it.close }
        val bbSeries = MarketRegimeDetector.bollingerSeries(chartCloses, 20, 2.0)

        val signalResult = SignalResult(
            symbol = symbol,
            timeframe = timeframe,
            regime = result.regime,
            signalType = result.signalType,
            entryPrice = result.entryPrice,
            recommendedExpirySeconds = result.recommendedExpirySeconds,
            confidenceScore = result.confidenceScore,
            reason = result.reason,
            timestamp = System.currentTimeMillis()
        )

        CycleResult(
            chartCandles = chartSlice,
            chartBbUpper = bbSeries.map { it?.upper },
            chartBbLower = bbSeries.map { it?.lower },
            liveClose = liveClose,
            changePct = changePct,
            bias = bias,
            showCall = showCall,
            checklist = result.checklist,
            allPass = result.allPass,
            volumeAvailable = result.volumeAvailable,
            regime = result.regime,
            signal = signalResult,
            lastOpenTime = last.openTime,
            lastClose = last.close
        )
    }
}
