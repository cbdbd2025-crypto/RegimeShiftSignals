package com.cwrvmultiwick.multiwick

import kotlin.math.abs

/**
 * Pure-Kotlin technical-indicator library + 4-regime market classifier.
 *
 * All indicator functions are SERIES functions: given N candles they return a
 * list of length N where index i is the indicator's value using only
 * candles[0..i] (null while there isn't enough history yet at that index).
 * That makes it trivial to look back at "yesterday's ADX" or compute a
 * rolling SMA-of-ATR without re-walking the candle list for every offset.
 *
 * detectRegime() runs the four regime rules in the priority order specified
 * by the trading plan: CHOPPY is checked first (it's a veto), then TRENDING,
 * then BREAKOUT, then RANGING. If nothing matches, REGIME_UNKNOWN is returned
 * (not enough data, or the market genuinely doesn't fit any bucket this bar).
 */
object MarketRegimeDetector {

    // ---------------------------------------------------------------------
    // EMA
    // ---------------------------------------------------------------------

    /** Exponential moving average series over closes. Seeded with an SMA of the first `period` closes. */
    fun emaSeries(closes: List<Double>, period: Int): List<Double?> {
        val out = arrayOfNulls<Double>(closes.size)
        if (closes.size < period || period <= 0) return out.toList()
        val k = 2.0 / (period + 1)
        var value = closes.subList(0, period).average()
        out[period - 1] = value
        for (i in period until closes.size) {
            value = closes[i] * k + value * (1 - k)
            out[i] = value
        }
        return out.toList()
    }

    fun ema(closes: List<Double>, period: Int): Double? = emaSeries(closes, period).lastOrNull()

    // ---------------------------------------------------------------------
    // SMA (generic, over a nullable double series)
    // ---------------------------------------------------------------------

    fun smaSeries(values: List<Double?>, period: Int): List<Double?> {
        val out = arrayOfNulls<Double>(values.size)
        if (period <= 0) return out.toList()
        for (i in values.indices) {
            if (i < period - 1) continue
            val window = values.subList(i - period + 1, i + 1)
            if (window.any { it == null }) continue
            out[i] = window.filterNotNull().average()
        }
        return out.toList()
    }

    // ---------------------------------------------------------------------
    // True Range / ATR (Wilder smoothing)
    // ---------------------------------------------------------------------

    fun trueRangeSeries(candles: List<Candle>): List<Double> {
        return candles.mapIndexed { i, c ->
            if (i == 0) {
                c.totalRange
            } else {
                val prevClose = candles[i - 1].close
                maxOf(c.high - c.low, abs(c.high - prevClose), abs(c.low - prevClose))
            }
        }
    }

    /** Wilder-smoothed ATR series. First value emitted once `period` true-range samples exist. */
    fun atrSeries(candles: List<Candle>, period: Int = 14): List<Double?> {
        val tr = trueRangeSeries(candles)
        val out = arrayOfNulls<Double>(candles.size)
        if (candles.size < period) return out.toList()
        var value = tr.subList(0, period).average()
        out[period - 1] = value
        for (i in period until candles.size) {
            value = (value * (period - 1) + tr[i]) / period
            out[i] = value
        }
        return out.toList()
    }

    fun atr(candles: List<Candle>, period: Int = 14): Double? = atrSeries(candles, period).lastOrNull()

    // ---------------------------------------------------------------------
    // ADX / +DI / -DI (Wilder)
    // ---------------------------------------------------------------------

    data class DmiResult(val adx: Double?, val plusDi: Double?, val minusDi: Double?)

    /** Full Wilder ADX/+DI/-DI series, index-aligned to `candles`. */
    fun dmiSeries(candles: List<Candle>, period: Int = 14): List<DmiResult> {
        val n = candles.size
        val empty = DmiResult(null, null, null)
        if (n < period + 1) return List(n) { empty }

        val tr = DoubleArray(n)
        val plusDm = DoubleArray(n)
        val minusDm = DoubleArray(n)
        for (i in 1 until n) {
            val cur = candles[i]
            val prev = candles[i - 1]
            tr[i] = maxOf(cur.high - cur.low, abs(cur.high - prev.close), abs(cur.low - prev.close))
            val upMove = cur.high - prev.high
            val downMove = prev.low - cur.low
            plusDm[i] = if (upMove > downMove && upMove > 0) upMove else 0.0
            minusDm[i] = if (downMove > upMove && downMove > 0) downMove else 0.0
        }

        val out = MutableList(n) { empty }

        // Wilder smoothing seeded at index `period`
        var smoothTr = (1..period).sumOf { tr[it] }
        var smoothPlusDm = (1..period).sumOf { plusDm[it] }
        var smoothMinusDm = (1..period).sumOf { minusDm[it] }

        fun diPair(): Pair<Double, Double> {
            val pDi = if (smoothTr > 0) 100.0 * smoothPlusDm / smoothTr else 0.0
            val mDi = if (smoothTr > 0) 100.0 * smoothMinusDm / smoothTr else 0.0
            return pDi to mDi
        }

        val dxValues = ArrayList<Double>()
        var (pDi, mDi) = diPair()
        out[period] = DmiResult(null, pDi, mDi)
        dxValues.add(dxOf(pDi, mDi))

        var adxValue: Double? = null
        for (i in (period + 1) until n) {
            smoothTr = smoothTr - smoothTr / period + tr[i]
            smoothPlusDm = smoothPlusDm - smoothPlusDm / period + plusDm[i]
            smoothMinusDm = smoothMinusDm - smoothMinusDm / period + minusDm[i]
            val pair = diPair()
            pDi = pair.first; mDi = pair.second
            dxValues.add(dxOf(pDi, mDi))

            adxValue = when {
                adxValue == null && dxValues.size >= period -> dxValues.takeLast(period).average()
                adxValue != null -> (adxValue!! * (period - 1) + dxValues.last()) / period
                else -> null
            }
            out[i] = DmiResult(adxValue, pDi, mDi)
        }
        return out
    }

    private fun dxOf(pDi: Double, mDi: Double): Double {
        val sum = pDi + mDi
        return if (sum > 0) 100.0 * abs(pDi - mDi) / sum else 0.0
    }

    fun adxSeries(candles: List<Candle>, period: Int = 14): List<Double?> = dmiSeries(candles, period).map { it.adx }

    fun adx(candles: List<Candle>, period: Int = 14): Double? = adxSeries(candles, period).lastOrNull()

    // ---------------------------------------------------------------------
    // RSI (Wilder)
    // ---------------------------------------------------------------------

    fun rsiSeries(closes: List<Double>, period: Int = 14): List<Double?> {
        val n = closes.size
        val out = arrayOfNulls<Double>(n)
        if (n < period + 1) return out.toList()

        val gains = DoubleArray(n)
        val losses = DoubleArray(n)
        for (i in 1 until n) {
            val change = closes[i] - closes[i - 1]
            gains[i] = if (change > 0) change else 0.0
            losses[i] = if (change < 0) -change else 0.0
        }

        var avgGain = (1..period).sumOf { gains[it] } / period
        var avgLoss = (1..period).sumOf { losses[it] } / period
        out[period] = rsiFrom(avgGain, avgLoss)

        for (i in (period + 1) until n) {
            avgGain = (avgGain * (period - 1) + gains[i]) / period
            avgLoss = (avgLoss * (period - 1) + losses[i]) / period
            out[i] = rsiFrom(avgGain, avgLoss)
        }
        return out.toList()
    }

    private fun rsiFrom(avgGain: Double, avgLoss: Double): Double {
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun rsi(closes: List<Double>, period: Int = 14): Double? = rsiSeries(closes, period).lastOrNull()

    // ---------------------------------------------------------------------
    // Bollinger Bands
    // ---------------------------------------------------------------------

    data class BollingerBands(val middle: Double, val upper: Double, val lower: Double, val bandwidth: Double)

    fun bollingerSeries(closes: List<Double>, period: Int = 20, stdevMultiplier: Double = 2.0): List<BollingerBands?> {
        val n = closes.size
        val out = arrayOfNulls<BollingerBands>(n)
        for (i in 0 until n) {
            if (i < period - 1) continue
            val window = closes.subList(i - period + 1, i + 1)
            val mean = window.average()
            val variance = window.sumOf { (it - mean) * (it - mean) } / period
            val stdev = kotlin.math.sqrt(variance)
            val upper = mean + stdevMultiplier * stdev
            val lower = mean - stdevMultiplier * stdev
            val bandwidth = if (mean != 0.0) (upper - lower) / mean else 0.0
            out[i] = BollingerBands(mean, upper, lower, bandwidth)
        }
        return out.toList()
    }

    // ---------------------------------------------------------------------
    // Wick / body ratios
    // ---------------------------------------------------------------------

    /** (upperWick + lowerWick) / totalRange for one candle. 0 for a zero-range candle. */
    fun wickToRangeRatio(c: Candle): Double =
        if (c.totalRange > 0) (c.upperWick + c.lowerWick) / c.totalRange else 0.0

    /** body / totalRange for one candle. 0 for a zero-range candle. */
    fun bodyToRangeRatio(c: Candle): Double =
        if (c.totalRange > 0) c.body / c.totalRange else 0.0

    fun donchianHigh(candles: List<Candle>, endExclusive: Int, lookback: Int): Double? {
        val from = maxOf(0, endExclusive - lookback)
        if (from >= endExclusive) return null
        return candles.subList(from, endExclusive).maxOf { it.high }
    }

    fun donchianLow(candles: List<Candle>, endExclusive: Int, lookback: Int): Double? {
        val from = maxOf(0, endExclusive - lookback)
        if (from >= endExclusive) return null
        return candles.subList(from, endExclusive).minOf { it.low }
    }

    // ---------------------------------------------------------------------
    // Regime detection
    // ---------------------------------------------------------------------

    object Thresholds {
        const val ATR_SPIKE_MULTIPLIER = 1.8
        const val ATR_SMA_PERIOD = 50
        const val CHOPPY_WICK_RATIO = 0.65
        const val CHOPPY_LOOKBACK = 5

        const val ADX_TREND_MIN = 25.0
        const val EMA_FAST = 20
        const val EMA_SLOW = 50

        const val BB_PERIOD = 20
        const val BB_STDEV = 2.0
        const val BB_BANDWIDTH_EXPANSION = 0.30
        const val BB_BANDWIDTH_LOOKBACK = 10
        const val BREAKOUT_BODY_RATIO = 0.70
        const val DONCHIAN_PERIOD = 20

        const val ADX_RANGING_MAX = 20.0
        const val RANGING_SLOPE_LOOKBACK = 10
        const val RANGING_FLAT_SLOPE_PCT = 0.0015 // ~0.15% drift over the lookback counts as "flat"

        const val RSI_OVERBOUGHT = 70.0
        const val RSI_OVERSOLD = 30.0
    }

    /** Snapshot of every indicator used by the regime rules, for the most recent (last) candle. */
    data class RegimeContext(
        val regime: MarketRegime,
        val atr: Double?,
        val atrSmaBaseline: Double?,
        val adx: Double?,
        val emaFast: Double?,
        val emaSlow: Double?,
        val bollinger: BollingerBands?,
        val rsi: Double?,
        val choppyWickRatio: Double?,
        val bandwidthExpansionPct: Double?
    )

    /**
     * Classify the most recent candle in `candles` (last element = latest closed bar)
     * using the last up-to-50 candles of context, in strict priority order:
     * CHOPPY -> TRENDING -> BREAKOUT -> RANGING.
     */
    fun detectRegime(candles: List<Candle>): MarketRegime = analyze(candles).regime

    fun analyze(candlesIn: List<Candle>): RegimeContext {
        val candles = if (candlesIn.size > 50) candlesIn.takeLast(50) else candlesIn
        val n = candles.size
        val closes = candles.map { it.close }

        val atrSeries = atrSeries(candles, 14)
        val atrNow = atrSeries.lastOrNull()
        val atrSma = smaSeries(atrSeries, Thresholds.ATR_SMA_PERIOD).lastOrNull()

        val adxNow = adx(candles, 14)
        val emaFastNow = ema(closes, Thresholds.EMA_FAST)
        val emaSlowNow = ema(closes, Thresholds.EMA_SLOW)

        val bbSeries = bollingerSeries(closes, Thresholds.BB_PERIOD, Thresholds.BB_STDEV)
        val bbNow = bbSeries.lastOrNull()
        val rsiNow = rsi(closes, 14)

        val wickRatio = if (n >= Thresholds.CHOPPY_LOOKBACK) {
            candles.takeLast(Thresholds.CHOPPY_LOOKBACK).map { wickToRangeRatio(it) }.average()
        } else null

        val bandwidthExpansion = run {
            val avgIdx = n - 1
            if (avgIdx < Thresholds.BB_BANDWIDTH_LOOKBACK) return@run null
            val recentBandwidths = bbSeries.takeLast(Thresholds.BB_BANDWIDTH_LOOKBACK).mapNotNull { it?.bandwidth }
            if (recentBandwidths.size < Thresholds.BB_BANDWIDTH_LOOKBACK || bbNow == null) return@run null
            val avgBandwidth = recentBandwidths.average()
            if (avgBandwidth <= 0) null else (bbNow.bandwidth - avgBandwidth) / avgBandwidth
        }

        if (n < 21) {
            return RegimeContext(MarketRegime.REGIME_UNKNOWN, atrNow, atrSma, adxNow, emaFastNow, emaSlowNow, bbNow, rsiNow, wickRatio, bandwidthExpansion)
        }

        val last = candles.last()

        // ---- Regime 1: CHOPPY (checked first, acts as a veto) ----
        val atrSpike = atrNow != null && atrSma != null && atrSma > 0 && atrNow > Thresholds.ATR_SPIKE_MULTIPLIER * atrSma
        val alternatingColors = if (n >= Thresholds.CHOPPY_LOOKBACK) {
            val last5 = candles.takeLast(Thresholds.CHOPPY_LOOKBACK)
            last5.zipWithNext().all { (a, b) -> a.isBullish != b.isBullish && !a.isDoji && !b.isDoji }
        } else false
        val wickHeavyChop = wickRatio != null && wickRatio > Thresholds.CHOPPY_WICK_RATIO && alternatingColors

        if (atrSpike || wickHeavyChop) {
            return RegimeContext(MarketRegime.REGIME_CHOPPY, atrNow, atrSma, adxNow, emaFastNow, emaSlowNow, bbNow, rsiNow, wickRatio, bandwidthExpansion)
        }

        // ---- Regime 2: TRENDING (up or down) ----
        if (adxNow != null && adxNow >= Thresholds.ADX_TREND_MIN && emaFastNow != null && emaSlowNow != null) {
            val bullish = emaFastNow > emaSlowNow && last.close > emaFastNow
            val bearish = emaFastNow < emaSlowNow && last.close < emaFastNow
            if (bullish) {
                return RegimeContext(MarketRegime.REGIME_TRENDING_UP, atrNow, atrSma, adxNow, emaFastNow, emaSlowNow, bbNow, rsiNow, wickRatio, bandwidthExpansion)
            }
            if (bearish) {
                return RegimeContext(MarketRegime.REGIME_TRENDING_DOWN, atrNow, atrSma, adxNow, emaFastNow, emaSlowNow, bbNow, rsiNow, wickRatio, bandwidthExpansion)
            }
        }

        // ---- Regime 3: BREAKOUT (momentum expansion) ----
        if (bandwidthExpansion != null && bandwidthExpansion > Thresholds.BB_BANDWIDTH_EXPANSION) {
            val bodyRatio = bodyToRangeRatio(last)
            val solidMomentumCandle = bodyRatio > Thresholds.BREAKOUT_BODY_RATIO
            val priorHigh = donchianHigh(candles, n - 1, Thresholds.DONCHIAN_PERIOD)
            val priorLow = donchianLow(candles, n - 1, Thresholds.DONCHIAN_PERIOD)
            val brokeOut = (priorHigh != null && last.close > priorHigh) || (priorLow != null && last.close < priorLow)
            if (solidMomentumCandle && brokeOut) {
                return RegimeContext(MarketRegime.REGIME_BREAKOUT, atrNow, atrSma, adxNow, emaFastNow, emaSlowNow, bbNow, rsiNow, wickRatio, bandwidthExpansion)
            }
        }

        // ---- Regime 4: RANGING (mean reversion) ----
        if (adxNow != null && adxNow < Thresholds.ADX_RANGING_MAX) {
            val lookback = Thresholds.RANGING_SLOPE_LOOKBACK
            val midNow = bbNow?.middle
            val midPast = if (n > lookback) bbSeries.getOrNull(n - 1 - lookback)?.middle else null
            val flat = midNow != null && midPast != null && midNow != 0.0 &&
                abs(midNow - midPast) / midNow <= Thresholds.RANGING_FLAT_SLOPE_PCT
            if (flat) {
                return RegimeContext(MarketRegime.REGIME_RANGING, atrNow, atrSma, adxNow, emaFastNow, emaSlowNow, bbNow, rsiNow, wickRatio, bandwidthExpansion)
            }
        }

        return RegimeContext(MarketRegime.REGIME_UNKNOWN, atrNow, atrSma, adxNow, emaFastNow, emaSlowNow, bbNow, rsiNow, wickRatio, bandwidthExpansion)
    }
}
