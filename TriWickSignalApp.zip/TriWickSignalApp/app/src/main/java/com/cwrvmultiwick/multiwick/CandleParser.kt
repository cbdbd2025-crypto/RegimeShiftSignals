package com.cwrvmultiwick.multiwick

import org.json.JSONArray
import org.json.JSONObject

/**
 * Resilient candle parser. Accepts several shapes seen across broker/exchange feeds:
 *
 *  1. A raw JSON array of candle objects:
 *       [{"time":..,"o":..,"h":..,"l":..,"c":..,"v":..}, ...]
 *
 *  2. A JSON object wrapping the array under a common key ("candles", "data",
 *     "result", "values", "klines"):
 *       {"candles": [ {...}, {...} ]}
 *
 *  3. Each candle object using EITHER short keys (time/o/h/l/c/v) OR full keys
 *     (timestamp/open/high/low/close/volume) OR OANDA-style nested "mid":
 *       {"time": "...", "mid": {"o":"1.0901","h":"1.0910","l":"1.0895","c":"1.0903"}, "volume": 120}
 *
 *  4. Each candle as a raw array/tuple (Binance kline style):
 *       [openTimeMs, "open", "high", "low", "close", "volume", ...]
 *
 * Any candle that can't be parsed (missing OHLC, non-numeric fields) is skipped
 * rather than throwing, so one malformed row doesn't take down an entire feed.
 * Output is sorted ascending by openTime and de-duplicated on openTime (last
 * write wins), matching how most REST candle endpoints stream partial + final
 * updates for the same bar.
 */
object CandleParser {

    /** Parse a raw JSON string (array or object) into a list of Candles, oldest first. */
    fun parse(json: String): List<Candle> {
        val trimmed = json.trim()
        if (trimmed.isEmpty()) return emptyList()
        return try {
            when {
                trimmed.startsWith("[") -> parseArray(JSONArray(trimmed))
                trimmed.startsWith("{") -> parseObject(JSONObject(trimmed))
                else -> emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private val WRAPPER_KEYS = listOf("candles", "data", "result", "values", "klines", "history", "items")

    private fun parseObject(obj: JSONObject): List<Candle> {
        for (key in WRAPPER_KEYS) {
            if (obj.has(key)) {
                val v = obj.opt(key)
                if (v is JSONArray) return parseArray(v)
                if (v is JSONObject) return parseObject(v)
            }
        }
        // Some feeds nest one level deeper, e.g. {"data": {"candles": [...]}}
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = obj.opt(k)
            if (v is JSONArray && v.length() > 0 && (v.opt(0) is JSONObject || v.opt(0) is JSONArray)) {
                return parseArray(v)
            }
        }
        return emptyList()
    }

    private fun parseArray(arr: JSONArray): List<Candle> {
        val out = ArrayList<Candle>(arr.length())
        for (i in 0 until arr.length()) {
            val item = arr.opt(i)
            val candle = when (item) {
                is JSONObject -> parseCandleObject(item)
                is JSONArray -> parseCandleTuple(item)
                else -> null
            }
            if (candle != null) out.add(candle)
        }
        return out
            .groupBy { it.openTime }
            .map { (_, group) -> group.last() }
            .sortedBy { it.openTime }
    }

    private fun num(v: Any?): Double? = when (v) {
        null -> null
        is Number -> v.toDouble()
        is String -> v.toDoubleOrNull()
        else -> null
    }

    private fun firstNonNull(obj: JSONObject, vararg keys: String): Any? {
        for (k in keys) {
            if (obj.has(k) && !obj.isNull(k)) return obj.opt(k)
        }
        return null
    }

    private fun parseCandleObject(obj: JSONObject): Candle? {
        // OANDA-style nested price object: {"time":..,"mid":{"o":..,"h":..,"l":..,"c":..}}
        val priceSource = when {
            obj.has("mid") && obj.opt("mid") is JSONObject -> obj.getJSONObject("mid")
            obj.has("ask") && obj.opt("ask") is JSONObject -> obj.getJSONObject("ask")
            obj.has("bid") && obj.opt("bid") is JSONObject -> obj.getJSONObject("bid")
            else -> obj
        }

        val timeRaw = firstNonNull(obj, "time", "timestamp", "openTime", "open_time", "t", "date")
        val openTime = parseTime(timeRaw) ?: return null

        val open = num(firstNonNull(priceSource, "o", "open")) ?: return null
        val high = num(firstNonNull(priceSource, "h", "high")) ?: return null
        val low = num(firstNonNull(priceSource, "l", "low")) ?: return null
        val close = num(firstNonNull(priceSource, "c", "close")) ?: return null
        val volume = num(firstNonNull(obj, "v", "volume", "vol")) ?: 0.0

        if (high < low) return null // corrupt tick, skip rather than crash downstream math
        return Candle(openTime, open, high, low, close, volume)
    }

    /** Binance-kline-style tuple: [openTime, open, high, low, close, volume, closeTime, ...] */
    private fun parseCandleTuple(arr: JSONArray): Candle? {
        if (arr.length() < 5) return null
        val openTime = parseTime(arr.opt(0)) ?: return null
        val open = num(arr.opt(1)) ?: return null
        val high = num(arr.opt(2)) ?: return null
        val low = num(arr.opt(3)) ?: return null
        val close = num(arr.opt(4)) ?: return null
        val volume = if (arr.length() > 5) num(arr.opt(5)) ?: 0.0 else 0.0
        if (high < low) return null
        return Candle(openTime, open, high, low, close, volume)
    }

    /** Accepts epoch millis, epoch seconds, or ISO-8601 strings; normalizes to epoch millis. */
    private fun parseTime(raw: Any?): Long? {
        return when (raw) {
            null -> null
            is Number -> {
                val l = raw.toLong()
                if (l in 1_000_000_000L..9_999_999_999L) l * 1000L else l // seconds -> millis
            }
            is String -> {
                raw.toLongOrNull()?.let { l ->
                    return if (l in 1_000_000_000L..9_999_999_999L) l * 1000L else l
                }
                try {
                    java.time.Instant.parse(raw).toEpochMilli()
                } catch (e: Exception) {
                    try {
                        java.time.OffsetDateTime.parse(raw).toInstant().toEpochMilli()
                    } catch (e2: Exception) {
                        null
                    }
                }
            }
            else -> null
        }
    }
}
