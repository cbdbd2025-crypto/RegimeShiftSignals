package com.cwrvmultiwick.multiwick

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.cwrvmultiwick.multiwick.data.Prefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = Prefs(context)
            if (prefs.serviceRunning) {
                val svcIntent = Intent(context, SignalForegroundService::class.java)
                ContextCompat.startForegroundService(context, svcIntent)
            }
        }
    }
}
